from django.apps import AppConfig


class SiteprojConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'SiteProj'
