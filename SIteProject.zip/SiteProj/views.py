from django.contrib.auth.decorators import login_required
from django.shortcuts import render

def home(request):
    return render(request, 'main/home.html')


def protected_view(request):
    return render(request, 'main/protected.html')

@login_required()
def about(request):
    return render(request, "main/about.html")

@login_required()
def contact(request):
    return render(request, "main/contact.html")

